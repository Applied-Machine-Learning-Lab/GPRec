import torch

from torchfm.layer import FeaturesLinear, MultiLayerPerceptron, FeaturesEmbedding


class MLP(torch.nn.Module):
    """
    A pytorch implementation of wide and deep learning.

    Reference:
        HT Cheng, et al. Wide & Deep Learning for Recommender Systems, 2016.
    """

    def __init__(self, field_dims, embed_dim, mlp_dims, dropout,gprec=False):
        super().__init__()
        self.embedding = FeaturesEmbedding(field_dims, embed_dim)
        self.embed_output_dim = len(field_dims) * embed_dim
        self.gprec=gprec
        if self.gprec:
            self.mlp = MultiLayerPerceptron(self.embed_output_dim+2*embed_dim, mlp_dims, dropout)
        else:
            self.mlp = MultiLayerPerceptron(self.embed_output_dim, mlp_dims, dropout)
        self.p_shapes = [self.mlp.weights_shape,self.mlp.bias_shape]

    def forward(self, x, custom_params=None, egp=None):
        """
        :param x: Long tensor of size ``(batch_size, num_fields)``
        """
        embed_x = self.embedding(x).view(-1, self.embed_output_dim)
        if self.gprec:
            embed_x = torch.cat([embed_x,egp], dim=1)
        x = self.mlp(embed_x, custom_params)
        return x.squeeze(1)
