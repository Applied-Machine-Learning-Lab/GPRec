import torch
import torch.nn as nn
from torchfm.layer import FeaturesEmbedding, CrossNetwork, MultiLayerPerceptron


class DeepCrossNetworkModel(torch.nn.Module):
    """
    A pytorch implementation of Deep & Cross Network.

    Reference:
        R Wang, et al. Deep & Cross Network for Ad Click Predictions, 2017.
    """

    def __init__(self, field_dims, embed_dim, num_layers, mlp_dims, dropout,gprec=False):
        super().__init__()
        self.embedding = FeaturesEmbedding(field_dims, embed_dim)
        self.embed_output_dim = len(field_dims) * embed_dim
        self.cn = CrossNetwork(self.embed_output_dim, num_layers)
        self.mlp = MultiLayerPerceptron(self.embed_output_dim, [self.embed_output_dim,self.embed_output_dim], dropout, output_layer=False)
        self.gprec=gprec
        if self.gprec:
            self.linear = MultiLayerPerceptron(self.embed_output_dim+self.embed_output_dim+2*embed_dim, mlp_dims, dropout)
        else:
            self.linear = MultiLayerPerceptron(self.embed_output_dim+self.embed_output_dim, mlp_dims, dropout)
        self.p_shapes = [self.linear.weights_shape,self.linear.bias_shape]
        


    def forward(self, x, custom_params=None, egp=None):
        """
        :param x: Long tensor of size ``(batch_size, num_fields)``
        """
        embed_x = self.embedding(x).view(-1, self.embed_output_dim)
        x_l1 = self.cn(embed_x)
        h_l2 = self.mlp(embed_x)
        x_stack = torch.cat([x_l1, h_l2], dim=1)
        if self.gprec:
            x_stack = torch.cat([x_stack,egp], dim=1)
        p = self.linear(x_stack, custom_params)
        return p.squeeze(1)
