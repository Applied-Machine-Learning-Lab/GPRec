import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F


class FeaturesLinear(torch.nn.Module):

    def __init__(self, field_dims, output_dim=1):
        super().__init__()
        self.fc = torch.nn.Embedding(sum(field_dims), output_dim)
        self.bias = torch.nn.Parameter(torch.zeros((output_dim,)))
        self.offsets = np.array((0, *np.cumsum(field_dims)[:-1]), dtype=np.int32)

    def forward(self, x):
        """
        :param x: Long tensor of size ``(batch_size, num_fields)``
        """
        x = x + x.new_tensor(self.offsets).unsqueeze(0)
        return torch.sum(self.fc(x), dim=1) + self.bias


class FeaturesEmbedding(torch.nn.Module):

    def __init__(self, field_dims, embed_dim):
        super().__init__()
        self.embedding = torch.nn.Embedding(sum(field_dims), embed_dim)
        self.offsets = np.array((0, *np.cumsum(field_dims)[:-1]), dtype=np.int32)
        torch.nn.init.xavier_uniform_(self.embedding.weight.data)

    def forward(self, x):
        """
        :param x: Long tensor of size ``(batch_size, num_fields)``
        """
        x = x + x.new_tensor(self.offsets).unsqueeze(0)
        return self.embedding(x)


class FieldAwareFactorizationMachine(torch.nn.Module):

    def __init__(self, field_dims, embed_dim):
        super().__init__()
        self.num_fields = len(field_dims)
        self.embeddings = torch.nn.ModuleList([
            torch.nn.Embedding(sum(field_dims), embed_dim) for _ in range(self.num_fields)
        ])
        self.offsets = np.array((0, *np.cumsum(field_dims)[:-1]), dtype=np.int32)
        for embedding in self.embeddings:
            torch.nn.init.xavier_uniform_(embedding.weight.data)

    def forward(self, x):
        """
        :param x: Long tensor of size ``(batch_size, num_fields)``
        """
        x = x + x.new_tensor(self.offsets).unsqueeze(0)
        xs = [self.embeddings[i](x) for i in range(self.num_fields)]
        ix = list()
        for i in range(self.num_fields - 1):
            for j in range(i + 1, self.num_fields):
                ix.append(xs[j][:, i] * xs[i][:, j])
        ix = torch.stack(ix, dim=1)
        return ix


class FactorizationMachine(torch.nn.Module):

    def __init__(self, reduce_sum=True):
        super().__init__()
        self.reduce_sum = reduce_sum

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        square_of_sum = torch.sum(x, dim=1) ** 2
        sum_of_square = torch.sum(x ** 2, dim=1)
        ix = square_of_sum - sum_of_square
        if self.reduce_sum:
            ix = torch.sum(ix, dim=1, keepdim=True)
        return 0.5 * ix


class MultiLayerPerceptron(torch.nn.Module):

    def __init__(self, input_dim, embed_dims, dropout, output_layer=1):
        super().__init__()
        self.output = bool(output_layer)
        self.weights = nn.ParameterList()
        self.biases = nn.ParameterList()
        self.batch_norms = nn.ModuleList()
        self.dropouts = nn.ModuleList()
        for embed_dim in embed_dims:
            self.weights.append(nn.Parameter(torch.randn(input_dim,embed_dim)))
            self.biases.append(nn.Parameter(torch.randn(embed_dim)))
            self.batch_norms.append(nn.BatchNorm1d(embed_dim))
            self.dropouts.append(nn.Dropout(p=dropout))
            input_dim = embed_dim
        if output_layer:
            self.weights.append(nn.Parameter(torch.randn(input_dim,output_layer)))
            self.biases.append(nn.Parameter(torch.randn(output_layer)))
        self.reset_parameters()
        self.weights_shape = list(map(lambda x: list(x.shape),self.weights))
        self.bias_shape = list(map(lambda x: list(x.shape),self.biases))

    def reset_parameters(self):
        for weight in self.weights:
            nn.init.kaiming_normal_(weight)
        for bias in self.biases:
            nn.init.zeros_(bias)

    def forward(self, x, custom_params=None):
        """
        :param x: Float tensor of size ``(batch_size, input_dim)``
        :param custom_params: Optional list of tuples containing custom weights and biases for each layer
        """
        batch_size = x.size(0)
        p=True
        if custom_params is None:
            p=False
            custom_params = [[torch.zeros_like(w.unsqueeze(0).repeat(batch_size, 1, 1)) for w in self.weights], [torch.zeros_like(b.unsqueeze(0).repeat(batch_size, 1)) for b in self.biases]]

        for i in range(len(self.weights) - int(self.output)):
            weight, bias = self.weights[i].unsqueeze(0).repeat(batch_size, 1, 1) + custom_params[0][i], self.biases[i].unsqueeze(0).repeat(batch_size, 1) + custom_params[1][i]
            x = torch.bmm(x.unsqueeze(1), weight).squeeze(1) + bias
            x = self.batch_norms[i](x)
            x = F.relu(x)
            x = self.dropouts[i](x)

        # Apply the output layer if it exists
        if self.output:
            weight, bias = self.weights[-1].unsqueeze(0).repeat(batch_size, 1, 1) + custom_params[0][-1], self.biases[-1].unsqueeze(0).repeat(batch_size, 1) + custom_params[1][-1]
            x = torch.bmm(x.unsqueeze(1), weight).squeeze(1) + bias
        return x



class InnerProductNetwork(torch.nn.Module):

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        num_fields = x.shape[1]
        row, col = list(), list()
        for i in range(num_fields - 1):
            for j in range(i + 1, num_fields):
                row.append(i), col.append(j)
        return torch.sum(x[:, row] * x[:, col], dim=2)


class OuterProductNetwork(torch.nn.Module):

    def __init__(self, num_fields, embed_dim, kernel_type='mat'):
        super().__init__()
        num_ix = num_fields * (num_fields - 1) // 2
        if kernel_type == 'mat':
            kernel_shape = embed_dim, num_ix, embed_dim
        elif kernel_type == 'vec':
            kernel_shape = num_ix, embed_dim
        elif kernel_type == 'num':
            kernel_shape = num_ix, 1
        else:
            raise ValueError('unknown kernel type: ' + kernel_type)
        self.kernel_type = kernel_type
        self.kernel = torch.nn.Parameter(torch.zeros(kernel_shape))
        torch.nn.init.xavier_uniform_(self.kernel.data)

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        num_fields = x.shape[1]
        row, col = list(), list()
        for i in range(num_fields - 1):
            for j in range(i + 1, num_fields):
                row.append(i), col.append(j)
        p, q = x[:, row], x[:, col]
        if self.kernel_type == 'mat':
            kp = torch.sum(p.unsqueeze(1) * self.kernel, dim=-1).permute(0, 2, 1)
            return torch.sum(kp * q, -1)
        else:
            return torch.sum(p * q * self.kernel.unsqueeze(0), -1)


class CrossNetwork(torch.nn.Module):

    def __init__(self, input_dim, num_layers):
        super().__init__()
        self.cross_layer_num = num_layers
        self.cross_layer_w = nn.ParameterList(
            nn.Parameter(
                torch.randn(input_dim,input_dim)
            )
            for _ in range(self.cross_layer_num)
        )
        self.cross_layer_b = nn.ParameterList(
            nn.Parameter(
                torch.zeros(input_dim)
            )
            for _ in range(self.cross_layer_num)
        )

    def forward(self, x_0):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        x_l = x_0
        for i in range(self.cross_layer_num):
            xl_w = F.linear(x_l, self.cross_layer_w[i], self.cross_layer_b[i])
            x_l = x_0 * xl_w + x_l
        return x_l


class AttentionalFactorizationMachine(torch.nn.Module):

    def __init__(self, embed_dim, attn_size, dropouts):
        super().__init__()
        self.attention = torch.nn.Linear(embed_dim, attn_size)
        self.projection = torch.nn.Linear(attn_size, 1)
        self.fc = torch.nn.Linear(embed_dim, 1)
        self.dropouts = dropouts

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        num_fields = x.shape[1]
        row, col = list(), list()
        for i in range(num_fields - 1):
            for j in range(i + 1, num_fields):
                row.append(i), col.append(j)
        p, q = x[:, row], x[:, col]
        inner_product = p * q
        attn_scores = F.relu(self.attention(inner_product))
        attn_scores = F.softmax(self.projection(attn_scores), dim=1)
        attn_scores = F.dropout(attn_scores, p=self.dropouts[0], training=self.training)
        attn_output = torch.sum(attn_scores * inner_product, dim=1)
        attn_output = F.dropout(attn_output, p=self.dropouts[1], training=self.training)
        return self.fc(attn_output)


class CompressedInteractionNetwork(torch.nn.Module):

    def __init__(self, input_dim, cross_layer_sizes, split_half=True):
        super().__init__()
        self.num_layers = len(cross_layer_sizes)
        self.split_half = split_half
        self.conv_layers = torch.nn.ModuleList()
        prev_dim, fc_input_dim = input_dim, 0
        for i in range(self.num_layers):
            cross_layer_size = cross_layer_sizes[i]
            self.conv_layers.append(torch.nn.Conv1d(input_dim * prev_dim, cross_layer_size, 1,
                                                    stride=1, dilation=1, bias=True))
            if self.split_half and i != self.num_layers - 1:
                cross_layer_size //= 2
            prev_dim = cross_layer_size
            fc_input_dim += prev_dim
        self.fc = torch.nn.Linear(fc_input_dim, 1)

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        xs = list()
        x0, h = x.unsqueeze(2), x
        for i in range(self.num_layers):
            x = x0 * h.unsqueeze(1)
            batch_size, f0_dim, fin_dim, embed_dim = x.shape
            x = x.view(batch_size, f0_dim * fin_dim, embed_dim)
            x = F.relu(self.conv_layers[i](x))
            if self.split_half and i != self.num_layers - 1:
                x, h = torch.split(x, x.shape[1] // 2, dim=1)
            else:
                h = x
            xs.append(x)
        return self.fc(torch.sum(torch.cat(xs, dim=1), 2))


class AnovaKernel(torch.nn.Module):

    def __init__(self, order, reduce_sum=True):
        super().__init__()
        self.order = order
        self.reduce_sum = reduce_sum

    def forward(self, x):
        """
        :param x: Float tensor of size ``(batch_size, num_fields, embed_dim)``
        """
        batch_size, num_fields, embed_dim = x.shape
        a_prev = torch.ones((batch_size, num_fields + 1, embed_dim), dtype=torch.float).to(x.device)
        for t in range(self.order):
            a = torch.zeros((batch_size, num_fields + 1, embed_dim), dtype=torch.float).to(x.device)
            a[:, t+1:, :] += x[:, t:, :] * a_prev[:, t:-1, :]
            a = torch.cumsum(a, dim=1)
            a_prev = a
        if self.reduce_sum:
            return torch.sum(a[:, -1, :], dim=-1, keepdim=True)
        else:
            return a[:, -1, :]


class MMoEModel(torch.nn.Module):
    def __init__(self, input_dim, bottom_mlp_dims, tower_mlp_dims, task_dims, expert_num, dropout):
        super().__init__()
        self.input_dim = input_dim
        self.task_dims = task_dims
        self.expert_num = expert_num
        task_num = len(task_dims)
        self.task_num = task_num
        self.expert = torch.nn.ModuleList([MultiLayerPerceptron(self.input_dim, bottom_mlp_dims, dropout, output_layer=0) for i in range(expert_num)])
        self.tower = torch.nn.ModuleList([MultiLayerPerceptron(bottom_mlp_dims[-1], tower_mlp_dims, dropout, output_layer=self.task_dims[i]) for i in range(task_num)])
        self.gate = torch.nn.ModuleList([torch.nn.Sequential(torch.nn.Linear(self.input_dim, expert_num), torch.nn.Softmax(dim=1)) for i in range(task_num)])

    def forward(self, emb):
        """
        :param 
        emb: Long tensor of size ``(batch_size, input_dims)``
        """
        gate_value = [self.gate[i](emb).unsqueeze(1) for i in range(self.task_num)]
        fea = torch.cat([self.expert[i](emb).unsqueeze(1) for i in range(self.expert_num)], dim = 1)
        task_fea = [torch.bmm(gate_value[i], fea).squeeze(1) for i in range(self.task_num)]
        results = [self.tower[i](task_fea[i]) for i in range(self.task_num)] # No activation for cross entropy loss
        return results

class MMoE(torch.nn.Module):
    def __init__(self, input_dim, bottom_mlp_dims, tower_mlp_dims, task_num, expert_num, dropout):
        super().__init__()
        self.input_dim = input_dim
        self.expert_num = expert_num
        self.task_num = task_num
        self.expert = torch.nn.ModuleList([MultiLayerPerceptron(self.input_dim, bottom_mlp_dims, dropout, output_layer=0) for i in range(expert_num)])
        self.tower = torch.nn.ModuleList([MultiLayerPerceptron(bottom_mlp_dims[-1], tower_mlp_dims, dropout) for i in range(task_num)])
        self.gate = torch.nn.ModuleList([torch.nn.Sequential(torch.nn.Linear(self.input_dim, expert_num), torch.nn.Softmax(dim=1)) for i in range(task_num)])

    def forward(self, emb,gt):
        """
        :param 
        emb: Long tensor of size ``(batch_size, input_dims)``
        """
        gate_value = [self.gate[i](emb).unsqueeze(1) for i in range(self.task_num)]
        fea = torch.cat([self.expert[i](emb).unsqueeze(1) for i in range(self.expert_num)], dim = 1)
        task_fea = [torch.bmm(gate_value[i], fea).squeeze(1) for i in range(self.task_num)]
        slot_mask = torch.nn.functional.one_hot(gt, self.task_num).bool().squeeze()
        results = torch.sigmoid(torch.sum(torch.cat([self.tower[i](task_fea[i]) for i in range(self.task_num)],-1)*slot_mask,-1))
        return results


class PLE(torch.nn.Module):
    def __init__(self, input_dim0, bottom_mlp_dims, tower_mlp_dims, task_num, shared_expert_num, specific_expert_num, dropout):
        # bottom_mlp_dims=(512, 256), tower_mlp_dims=(128, 64), task_num=task_num, shared_expert_num=int(expert_num / 2), specific_expert_num=int(expert_num / 2), dropout=0.2)
        super().__init__()
        self.input_dim0 = input_dim0 # Field_N+1
        self.task_num = task_num
        self.shared_expert_num = shared_expert_num
        self.specific_expert_num = specific_expert_num
        self.layers_num = len(bottom_mlp_dims)

        self.task_experts=[[0] * self.task_num for _ in range(self.layers_num)]
        self.task_gates=[[0] * self.task_num for _ in range(self.layers_num)]
        self.share_experts=[0] * self.layers_num
        self.share_gates=[0] * self.layers_num
        for i in range(self.layers_num):
            input_dim = self.input_dim0 if 0 == i else bottom_mlp_dims[i - 1]
            self.share_experts[i] = torch.nn.ModuleList([MultiLayerPerceptron(input_dim, [bottom_mlp_dims[i]], dropout, output_layer=False) for k in range(self.shared_expert_num)])
            self.share_gates[i]=torch.nn.Sequential(torch.nn.Linear(input_dim, shared_expert_num + task_num * specific_expert_num), torch.nn.Softmax(dim=1))
            for j in range(task_num):
                self.task_experts[i][j]=torch.nn.ModuleList([MultiLayerPerceptron(input_dim, [bottom_mlp_dims[i]], dropout, output_layer=False) for k in range(self.specific_expert_num)])
                self.task_gates[i][j]=torch.nn.Sequential(torch.nn.Linear(input_dim, shared_expert_num + specific_expert_num), torch.nn.Softmax(dim=1))
            self.task_experts[i]=torch.nn.ModuleList(self.task_experts[i])
            self.task_gates[i] = torch.nn.ModuleList(self.task_gates[i])

        self.task_experts = torch.nn.ModuleList(self.task_experts)
        self.task_gates = torch.nn.ModuleList(self.task_gates)
        self.share_experts = torch.nn.ModuleList(self.share_experts)
        self.share_gates = torch.nn.ModuleList(self.share_gates)


        self.tower = torch.nn.ModuleList([MultiLayerPerceptron(bottom_mlp_dims[-1], tower_mlp_dims, dropout) for i in range(task_num)])

    def forward(self, emb,gt):
        task_fea = [emb for i in range(self.task_num + 1)] # task1 input ,task2 input,..taskn input, share_expert input
        for i in range(self.layers_num):
            share_output=[expert(task_fea[-1]).unsqueeze(1) for expert in self.share_experts[i]]
            task_output_list=[]
            for j in range(self.task_num):
                task_output=[expert(task_fea[j]).unsqueeze(1) for expert in self.task_experts[i][j]]
                task_output_list.extend(task_output)
                mix_ouput=torch.cat(task_output+share_output,dim=1)
                gate_value = self.task_gates[i][j](task_fea[j]).unsqueeze(1)
                task_fea[j] = torch.bmm(gate_value, mix_ouput).squeeze(1)
            if i != self.layers_num-1:#最后一层不需要计算share expert 的输出
                gate_value = self.share_gates[i](task_fea[-1]).unsqueeze(1)
                mix_ouput = torch.cat(task_output_list + share_output, dim=1)
                task_fea[-1] = torch.bmm(gate_value, mix_ouput).squeeze(1)
        slot_mask = torch.nn.functional.one_hot(gt, self.task_num).bool().squeeze()
        results = torch.sigmoid(torch.sum(torch.cat([self.tower[i](task_fea[i]) for i in range(self.task_num)],-1)*slot_mask,-1))
        return results


class STAR(nn.Module):

    def __init__(self, input_dim, slot_num,embed_dim=16, star_output_dim=16):
        super().__init__()
        self.slot_num = slot_num
        self.input_dim = input_dim
        self.star_output_dim = star_output_dim
        # Auxilary Net
        self.auxiliary = MultiLayerPerceptron(self.input_dim, [16,8,8], dropout=0.2,output_layer=1)
        # Shared Parameter
        self.shared_weight = nn.Parameter(nn.init.xavier_uniform_(torch.empty(self.input_dim, star_output_dim)))
        self.shared_bias = nn.Parameter(torch.zeros(star_output_dim))
        # Specific Parameter
        self.slot_weights = nn.Parameter(torch.stack([nn.init.xavier_uniform_(torch.empty(input_dim, star_output_dim)) for _ in range(slot_num)], dim=0))
        self.slot_bias = nn.Parameter(torch.zeros(slot_num, star_output_dim))

        self.mlp = MultiLayerPerceptron(star_output_dim, [8,8], dropout=0.2,output_layer=1)


    def forward(self, emb, slot_id):
        b = emb.shape[0]
        sa = self.auxiliary(emb)
        combined_weights = self.shared_weight.unsqueeze(0) * self.slot_weights  # Element-wise multiplication S, IN, OUT
        combined_bias = self.shared_bias.unsqueeze(0) + self.slot_bias # S,OUT
                                        # B,1,IN In,Our,S
        slot_outputs = torch.einsum('bi,sij -> bsj', emb, combined_weights) + combined_bias.unsqueeze(0) # B,S,OUT
        slot_mask = torch.nn.functional.one_hot(slot_id, self.slot_num).bool().squeeze() # BS

        output = torch.sum(slot_mask.unsqueeze(-1) * slot_outputs, dim=1)

        output = self.mlp(output)
        ctr = torch.sigmoid(sa + output)
        # ctr = torch.sigmoid(output)
        return ctr





class MultiHeadAttention(nn.Module): 
    def __init__(self, d_model, num_heads=1):
        super(MultiHeadAttention, self).__init__()
        
        assert d_model % num_heads == 0, "d_model must be divisible by num_heads"
        
        self.num_heads = num_heads
        self.d_k = d_model // num_heads
        
        self.W_q = nn.Linear(d_model, d_model)
        self.W_k = nn.Linear(d_model, d_model)
        self.W_v = nn.Linear(d_model, d_model)
        self.W_o = nn.Linear(d_model, d_model)
        
    def split_heads(self, x, batch_size, seq_len):
        x = x.view(batch_size, seq_len, self.num_heads, self.d_k)
        return x.permute(0, 2, 1, 3)
        
    def forward(self, query, key, value):
        batch_size = query.size(0)
        seq_len_q = query.size(1)
        seq_len_k = key.size(1)
        
        Q = self.split_heads(self.W_q(query), batch_size, seq_len_q)
        K = self.split_heads(self.W_k(key), batch_size, seq_len_k)
        V = self.split_heads(self.W_v(value), batch_size, seq_len_k)
        
        scores = torch.matmul(Q, K.transpose(-2, -1)) / torch.sqrt(torch.tensor(self.d_k, dtype=torch.float32))
        attention_weights = F.softmax(scores, dim=-1)
        output = torch.matmul(attention_weights, V)
        
        output_ = self.W_o(output.permute(0, 2, 1, 3).contiguous().view(batch_size, seq_len_q, self.num_heads * self.d_k))
        return output_

