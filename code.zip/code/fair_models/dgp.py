import torch
import torch.nn as nn 
import torch.nn.functional as F
import numpy as np
from utils import get_model
from torchfm.layer import MultiLayerPerceptron
import time
import os

class DGP(nn.Module):
    def __init__(self,model_name, field_dims, user_idx): # The first idx of user_idx is ID
        super().__init__()
        self.g_num = 60
        self.backbone = get_model(model_name,field_dims)
        self.p_shapes = self.backbone.p_shapes
        self.cus_w_num = np.prod(self.p_shapes[0],-1)
        self.cus_b_num = np.prod(self.p_shapes[1],-1)
        self.criterion = nn.CrossEntropyLoss()
        self.embed_dim = 16 
        self.user_idx = user_idx
        self.other_idx = [idx for idx in list(range(len(field_dims))) if idx not in user_idx]
        self.input_dim = len(field_dims)*self.embed_dim
        self.input_dim_u = len(user_idx) * self.embed_dim  
        self.input_dim_o = len(self.other_idx) * self.embed_dim
        self.tau= 0.5
        self.Group_Pos_Embedding = nn.init.xavier_uniform_(nn.Parameter(torch.empty([self.g_num,  self.embed_dim])))# Group Embeddings  G,2,e
        self.Group_Neg_Embedding = nn.init.xavier_uniform_(nn.Parameter(torch.empty([self.g_num,  self.embed_dim])))
        self.Group_pred = nn.Sequential(
            nn.Linear(self.embed_dim+self.input_dim_o,self.embed_dim), #*self.g_num
            nn.ReLU(),
            nn.Linear(self.embed_dim,1)
        )
        self.Group_mlp = nn.Sequential(
            nn.Linear(self.embed_dim+self.input_dim_o,self.embed_dim), #*self.g_num
            nn.ReLU(),
            nn.Linear(self.embed_dim,1)
        )
        self.ID_mlp = nn.Sequential(
            nn.Linear(self.embed_dim+self.input_dim_o,self.embed_dim), # *self.g_num
            nn.ReLU(),
            nn.Linear(self.embed_dim,1)
        )
        self.Proj = nn.Sequential(
                nn.BatchNorm1d(self.input_dim_u),
                nn.Linear(self.input_dim_u,self.g_num*2)
        )
        self.id_trans = nn.Sequential(
                nn.Linear(self.embed_dim,self.embed_dim*self.g_num // 2),
                nn.ReLU(),
                nn.Linear(self.embed_dim*self.g_num // 2, self.embed_dim)#*self.g_num
            )
        self.Rec = nn.Sequential(
                nn.Linear(self.embed_dim*2,self.embed_dim*self.g_num),#*self.g_num
                nn.ReLU(),
                nn.Linear(self.embed_dim*self.g_num,self.input_dim_u)
            )
        self.hard=False
        self.step = 0

    def forward(self,x):
        device = x.device
        batch_size = x.size(0)
        embed_x = self.backbone.embedding(x)
        user_emb = embed_x[:,self.user_idx].clone()#.detach() # b,u,e
        other_emb = embed_x[:,self.other_idx].clone()#.detach() # b,o,e
        id_emb = user_emb[:,0].clone() # b,e 
        e_id = self.id_trans(id_emb) + id_emb# b, ge
        we_g = self.Proj(user_emb.view(-1,self.input_dim_u)).view(-1,self.g_num,2) # b,g,2
        if self.training:
            w_g = F.gumbel_softmax(we_g, tau=self.tau, hard=self.hard, dim=-1)[:,:,0].unsqueeze(-1) #b,g,1
        else:
            w_g = (we_g/self.tau).softmax(-1)[:,:,0].unsqueeze(-1)
        e_g = (w_g*self.Group_Pos_Embedding + (1-w_g) * self.Group_Neg_Embedding).sum(1)#.view(-1,self.g_num*self.embed_dim) # b,g,e
        e_g_con = ((1-w_g)*self.Group_Pos_Embedding + w_g * self.Group_Neg_Embedding).sum(1)# .view(-1,self.g_num*self.embed_dim)
        p_g = torch.cat([e_g,e_id],-1)
        logit_g = self.Group_mlp(torch.cat([e_g,other_emb.view(-1,self.input_dim_o)],-1)).squeeze(1)
        logit_id = self.ID_mlp(torch.cat([e_id,other_emb.view(-1,self.input_dim_o)],-1)).squeeze(1)
        y_main = torch.sigmoid(self.backbone(x))
        y_pred = torch.sigmoid((self.backbone(x)+logit_g+ logit_id)/3)
        if self.training:
            adv_loss = self.compute_cossim(e_g,e_id)
            sim_loss = 1e-4*adv_loss
            y_g = torch.sigmoid(logit_g)
            original_requires_grad = [p.requires_grad for p in self.Group_mlp.parameters()]
            for p in self.Group_mlp.parameters():
                p.requires_grad = False
            y_g_con = torch.sigmoid(self.Group_mlp(torch.cat([e_g_con,other_emb.view(-1,self.input_dim_o).detach()],-1))).squeeze(1)
            for p, req_grad in zip(self.Group_mlp.parameters(), original_requires_grad):
                p.requires_grad = req_grad
            return y_pred, sim_loss, [y_g,y_g_con], y_main, torch.sigmoid(logit_id)#y_g_con
        return y_pred


    def compute_cossim(self, group_emb,per_emb):
        b,g = group_emb.shape
        norm_g = F.normalize(group_emb,p=2,dim=1)
        norm_p = F.normalize(per_emb,p=2,dim=1)
        cossim = torch.sum(norm_g*norm_p,dim=[1]).abs().mean()
        return cossim